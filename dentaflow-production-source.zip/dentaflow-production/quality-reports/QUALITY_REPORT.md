# DentaFlow automated quality report

Generated: 2026-08-03T14:50:06.177644+00:00

Overall gate: **PASS**

Critical: 0 · High: 0 · Medium: 0 · Low: 1

## architecture
Gate: **PASS**

No findings.

## ux-and-design-system
Gate: **PASS**

No findings.

## security
Gate: **PASS**

No findings.

## performance
Gate: **PASS**

- **LOW — large-module**: 644 lines; monitor maintainability (`src/domain/types.ts`)

## usability-and-flow
Gate: **PASS**

No findings.

## data-model
Gate: **PASS**

No findings.

## runtime-contracts
Gate: **PASS**

No findings.

## sql-safety
Gate: **PASS**

No findings.
