import React, { useMemo, useState } from 'react';
import { RefreshControl, View } from 'react-native';
import { FlashList } from '@shopify/flash-list';
import { useRouter } from 'expo-router';
import { AlertCircle, BadgeIndianRupee, Clock3, HeartPulse, UserRoundPlus, UsersRound } from '@/ui/icons';
import { AppText, Chip, ErrorState, FloatingAction, LoadingState, PageHeader, PatientRow, SearchField, Surface } from '@/ui/components';
import { spacing } from '@/ui/tokens';
import { useTheme } from '@/ui/ThemeProvider';
import { usePatients } from '@/hooks/useClinicQueries';
import { useUIStore } from '@/store/uiStore';
import type { PatientFilters } from '@/repositories';

const filters: Array<{ value: NonNullable<PatientFilters['flag']>; label: string }> = [
  { value: 'all', label: 'All' }, { value: 'medical-alerts', label: 'Medical alerts' }, { value: 'incomplete-intake', label: 'Intake review' },
  { value: 'outstanding', label: 'Balance due' }, { value: 'recall', label: 'Recall' }, { value: 'pending-treatment', label: 'Pending care' }
];

export function PatientsScreen() {
  const [query, setQuery] = useState('');
  const [flag, setFlag] = useState<NonNullable<PatientFilters['flag']>>('all');
  const theme = useTheme();
  const router = useRouter();
  const setCommandOpen = useUIStore((state) => state.setCommandOpen);
  const result = usePatients({ query: query || undefined, flag });
  const recent = useMemo(() => result.data?.slice().sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, 3) ?? [], [result.data]);

  return <View style={{ flex: 1, backgroundColor: theme.colors.canvas }}>
    <PageHeader title="Patients" subtitle="Clinical, communication, treatment, and financial context in one record" onSearch={() => setCommandOpen(true)} />
    <View style={{ paddingHorizontal: spacing[4], gap: spacing[3] }}>
      <SearchField value={query} onChangeText={setQuery} placeholder="Name, phone, email, patient number, or tag" />
      <FlashList horizontal data={filters} keyExtractor={(item) => item.value} renderItem={({ item }) => <View style={{ marginRight: spacing[2] }}><Chip label={item.label} selected={flag === item.value} onPress={() => setFlag(item.value)} /></View>} showsHorizontalScrollIndicator={false} />
    </View>

    {result.isLoading ? <LoadingState label="Loading patient directory…" /> : result.isError ? <ErrorState message={result.error instanceof Error ? result.error.message : undefined} onRetry={() => result.refetch()} /> : (
      <FlashList
        data={result.data ?? []}
        keyExtractor={(item) => item.id}
        estimatedItemSize={96}
        refreshControl={<RefreshControl refreshing={result.isRefetching} onRefresh={() => result.refetch()} tintColor={theme.colors.clinical} />}
        contentContainerStyle={{ paddingHorizontal: spacing[4], paddingTop: spacing[5], paddingBottom: 130 }}
        ListHeaderComponent={query || flag !== 'all' || recent.length === 0 ? null : <View style={{ marginBottom: spacing[5], gap: spacing[3] }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[2] }}><Clock3 size={18} color={theme.colors.textSecondary} /><AppText variant="title3">Recently opened</AppText></View><Surface padded={false}>{recent.map((patient, index) => <View key={patient.id} style={{ paddingHorizontal: spacing[4], borderBottomWidth: index < recent.length - 1 ? 1 : 0, borderBottomColor: theme.colors.border }}><PatientRow patient={patient} onPress={() => router.push(`/patient/${patient.id}` as never)} /></View>)}</Surface><View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[2], marginTop: spacing[2] }}><UsersRound size={18} color={theme.colors.textSecondary} /><AppText variant="title3">All patients</AppText><AppText variant="caption" tone="muted">{result.data?.length ?? 0}</AppText></View></View>}
        renderItem={({ item, index }) => <View style={{ backgroundColor: theme.colors.surface, paddingHorizontal: spacing[4], borderTopLeftRadius: index === 0 ? 16 : 0, borderTopRightRadius: index === 0 ? 16 : 0, borderBottomLeftRadius: index === (result.data?.length ?? 1) - 1 ? 16 : 0, borderBottomRightRadius: index === (result.data?.length ?? 1) - 1 ? 16 : 0, borderWidth: 1, borderTopWidth: index === 0 ? 1 : 0, borderColor: theme.colors.border, borderBottomWidth: 1 }}><PatientRow patient={item} onPress={() => router.push(`/patient/${item.id}` as never)} /></View>}
        ListEmptyComponent={<View style={{ paddingTop: 80, alignItems: 'center', gap: spacing[3] }}><AlertCircle size={28} color={theme.colors.textMuted} /><AppText variant="title3">No patients match this view</AppText><AppText tone="secondary" style={{ textAlign: 'center' }}>Change the search or filter, or create a new patient intake.</AppText></View>}
      />
    )}
    <FloatingAction label="Add patient" icon={UserRoundPlus} onPress={() => router.push('/patient/new')} />
  </View>;
}
