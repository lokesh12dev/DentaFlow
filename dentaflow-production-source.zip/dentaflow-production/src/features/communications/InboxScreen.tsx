import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { router } from 'expo-router';
import type { CommunicationChannel } from '@/domain/types';
import { useBookingRequests, useCommunications, useMarkCommunicationRead } from '@/hooks/useClinicQueries';
import { useUIStore } from '@/store/uiStore';
import { CalendarDays, Inbox, MessageCircle, Phone, Mail, Send, Plus } from '@/ui/icons';
import { AppText, Badge, Button, Chip, CommunicationRow, EmptyState, ErrorState, FloatingAction, LoadingState, PageHeader, Screen, SectionHeader, Surface } from '@/ui/components';
import { spacing } from '@/ui/tokens';
import { useTheme } from '@/ui/ThemeProvider';

const filters: Array<{ label: string; value: 'all' | CommunicationChannel | 'follow-up' | 'unread' }> = [
  { label: 'All', value: 'all' }, { label: 'Unread', value: 'unread' }, { label: 'Missed calls', value: 'call' }, { label: 'WhatsApp', value: 'whatsapp' }, { label: 'Email', value: 'email' }, { label: 'Follow-up', value: 'follow-up' }
];

export function InboxScreen() {
  const theme = useTheme();
  const query = useCommunications();
  const bookingRequests = useBookingRequests();
  const markRead = useMarkCommunicationRead();
  const [filter, setFilter] = useState<(typeof filters)[number]['value']>('all');
  const [selected, setSelected] = useState<string>();
  const setCommand = useUIStore((s) => s.setCommandOpen);
  const rows = useMemo(() => (query.data ?? []).filter((item) => {
    if (filter === 'all') return true;
    if (filter === 'unread') return item.unread;
    if (filter === 'follow-up') return item.requiresFollowUp;
    if (filter === 'call') return item.channel === 'call' && item.status === 'missed';
    return item.channel === filter;
  }), [query.data, filter]);
  const missed = (query.data ?? []).filter((i) => i.channel === 'call' && i.status === 'missed' && i.requiresFollowUp);
  const unread = (query.data ?? []).filter((i) => i.unread).length;
  const newBookingRequests = (bookingRequests.data ?? []).filter((item) => item.status === 'new').length;

  return <Screen>
    <PageHeader title="Inbox" subtitle="One patient conversation across every channel" onSearch={() => setCommand(true)} notificationCount={unread} onNotifications={() => setFilter('unread')} />
    <View style={{ paddingHorizontal: spacing[4], gap: spacing[4] }}>
      {newBookingRequests ? <Surface tone="clinical" style={{ gap: spacing[3] }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[3] }}><View style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: theme.colors.clinical, alignItems: 'center', justifyContent: 'center' }}><CalendarDays size={20} color={theme.colors.textInverse} /></View><View style={{ flex: 1 }}><AppText variant="bodyStrong">{newBookingRequests} online booking request{newBookingRequests === 1 ? '' : 's'}</AppText><AppText tone="secondary">Verify identity and availability before creating an appointment.</AppText></View><Button label="Review" size="small" tone="secondary" onPress={() => router.push('/booking-requests')} /></View></Surface> : null}

      {missed.length ? <Surface tone="danger" style={{ gap: spacing[3] }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[3] }}><View style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: theme.colors.danger, alignItems: 'center', justifyContent: 'center' }}><Phone size={20} color={theme.colors.textInverse} /></View><View style={{ flex: 1 }}><AppText variant="bodyStrong">{missed.length} missed calls need a response</AppText><AppText tone="secondary">Oldest callback is still unassigned.</AppText></View><Button label="Open queue" size="small" tone="secondary" onPress={() => setFilter('call')} /></View></Surface> : null}

      <Surface style={{ gap: spacing[3] }}><SectionHeader title="Conversation filters" subtitle="Messages stay grouped by patient, not provider" icon={Inbox} /><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[2] }}>{filters.map((item) => <Chip key={item.value} label={item.label} selected={filter === item.value} onPress={() => setFilter(item.value)} />)}</View></Surface>

      <Surface style={{ gap: 0 }}><SectionHeader title={filter === 'all' ? 'All conversations' : filters.find((f) => f.value === filter)?.label ?? 'Conversations'} subtitle={`${rows.length} items · newest first`} icon={MessageCircle} actionLabel="New" onAction={() => router.push('/communication/new')} />
        {query.isLoading ? <LoadingState /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : rows.length === 0 ? <EmptyState title="Inbox is clear" message="There are no conversations matching this filter." icon={Inbox} /> : rows.map((communication, index) => <View key={communication.id}><CommunicationRow communication={communication} onPress={() => { setSelected(communication.id); if (communication.unread) markRead.mutate(communication.id); router.push({ pathname: '/communication/new', params: { patientId: communication.patientId, channel: communication.channel, replyTo: communication.id } }); }} />{index < rows.length - 1 ? <View style={{ height: 1, backgroundColor: theme.colors.border }} /> : null}</View>)}
      </Surface>

      <Surface style={{ gap: spacing[3] }}><SectionHeader title="Channel health" subtitle="Provider status and delivery visibility" icon={Send} /><Channel icon={MessageCircle} title="WhatsApp Business" detail="Templates approved · delivery webhooks active" tone="success" /><Channel icon={Mail} title="Email" detail="Transactional sender connected" tone="success" /><Channel icon={Phone} title="Cloud telephony" detail="Native call fallback available" tone="warning" /></Surface>
    </View>
    <FloatingAction label="New message" icon={Plus} onPress={() => router.push('/communication/new')} />
  </Screen>;
}
function Channel({ icon: Icon, title, detail, tone }: { icon: typeof Phone; title: string; detail: string; tone: 'success' | 'warning' }) { const theme = useTheme(); return <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[3], minHeight: 52 }}><View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: tone === 'success' ? theme.colors.successSoft : theme.colors.warningSoft, alignItems: 'center', justifyContent: 'center' }}><Icon size={18} color={tone === 'success' ? theme.colors.success : theme.colors.warning} /></View><View style={{ flex: 1 }}><AppText variant="bodyStrong">{title}</AppText><AppText variant="caption" tone="secondary">{detail}</AppText></View><Badge label={tone === 'success' ? 'Ready' : 'Fallback'} tone={tone} /></View>; }
