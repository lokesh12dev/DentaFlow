import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { addDays, format, isSameDay, startOfWeek } from 'date-fns';
import { router } from 'expo-router';
import { useAppointments, useStaff } from '@/hooks/useClinicQueries';
import { useUIStore } from '@/store/uiStore';
import type { AppointmentView } from '@/domain/types';
import { CalendarDays, ChevronLeft, ChevronRight, Filter, Plus, SlidersHorizontal } from '@/ui/icons';
import { AppointmentRow, Badge, Chip, ErrorState, FloatingAction, IconButton, LoadingState, PageHeader, Screen, SectionHeader, SegmentedControl, Surface, AppText } from '@/ui/components';
import { spacing } from '@/ui/tokens';
import { useTheme } from '@/ui/ThemeProvider';

const viewOptions: Array<{ label: string; value: AppointmentView }> = [
  { label: 'Day', value: 'day' }, { label: 'Week', value: 'week' }, { label: 'Doctor', value: 'doctor' }, { label: 'Chair', value: 'chair' }
];

export function CalendarScreen() {
  const theme = useTheme();
  const setCommand = useUIStore((s) => s.setCommandOpen);
  const toast = useUIStore((s) => s.showToast);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [view, setView] = useState<AppointmentView>('day');
  const [doctorId, setDoctorId] = useState<string>();
  const dateKey = format(selectedDate, 'yyyy-MM-dd');
  const appointmentsQuery = useAppointments(view === 'week' ? undefined : { date: dateKey, doctorId });
  const staffQuery = useStaff();
  const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
  const days = useMemo(() => Array.from({ length: view === 'week' ? 7 : 9 }, (_, i) => addDays(view === 'week' ? weekStart : addDays(selectedDate, -4), i)), [selectedDate, view, weekStart]);
  const appointments = useMemo(() => {
    const rows = appointmentsQuery.data ?? [];
    if (view !== 'week') return rows;
    const from = format(weekStart, 'yyyy-MM-dd');
    const to = format(addDays(weekStart, 6), 'yyyy-MM-dd');
    return rows.filter((a) => a.startsAt.slice(0, 10) >= from && a.startsAt.slice(0, 10) <= to && (!doctorId || a.doctorId === doctorId));
  }, [appointmentsQuery.data, view, weekStart, doctorId]);
  const conflicts = useMemo(() => appointments.filter((item, index) => appointments.some((other, otherIndex) => index !== otherIndex && item.chairId === other.chairId && item.startsAt < other.endsAt && item.endsAt > other.startsAt)), [appointments]);
  const grouped = useMemo(() => {
    const map = new Map<string, typeof appointments>();
    appointments.forEach((item) => { const key = item.startsAt.slice(0, 10); map.set(key, [...(map.get(key) ?? []), item]); });
    return map;
  }, [appointments]);

  return <Screen>
    <PageHeader title="Calendar" subtitle="Doctors, chairs and treatment availability" onSearch={() => setCommand(true)} right={<IconButton label="Calendar filters" icon={SlidersHorizontal} onPress={() => toast('Use clinician and chair chips to filter the schedule', 'neutral')} />} />
    <View style={{ paddingHorizontal: spacing[4], gap: spacing[4] }}>
      <SegmentedControl value={view} options={viewOptions} onChange={setView} />
      <Surface style={{ gap: spacing[3] }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <IconButton label="Previous period" icon={ChevronLeft} onPress={() => setSelectedDate(addDays(selectedDate, view === 'week' ? -7 : -1))} />
          <View style={{ flex: 1, alignItems: 'center' }}><AppText variant="title3">{view === 'week' ? `${format(weekStart, 'd MMM')} – ${format(addDays(weekStart, 6), 'd MMM yyyy')}` : format(selectedDate, 'EEEE, d MMMM')}</AppText><AppText variant="caption" tone="secondary">{appointments.length} scheduled visits</AppText></View>
          <IconButton label="Next period" icon={ChevronRight} onPress={() => setSelectedDate(addDays(selectedDate, view === 'week' ? 7 : 1))} />
        </View>
        <View style={{ flexDirection: 'row', gap: spacing[2] }}>{days.map((day) => {
          const active = isSameDay(day, selectedDate);
          return <Pressable key={day.toISOString()} accessibilityRole="button" accessibilityState={{ selected: active }} accessibilityLabel={format(day, 'EEEE d MMMM')} onPress={() => setSelectedDate(day)} style={{ flex: 1, minWidth: 36, minHeight: 58, borderRadius: 12, backgroundColor: active ? theme.colors.primary : theme.colors.surfaceSecondary, alignItems: 'center', justifyContent: 'center', gap: 2 }}><AppText variant="tiny" style={{ color: active ? theme.colors.textInverse : theme.colors.textMuted }}>{format(day, 'EEE').slice(0, 1)}</AppText><AppText variant="bodyStrong" style={{ color: active ? theme.colors.textInverse : theme.colors.text }}>{format(day, 'd')}</AppText>{(grouped.get(format(day, 'yyyy-MM-dd'))?.length ?? 0) > 0 ? <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: active ? theme.colors.textInverse : theme.colors.clinical }} /> : null}</Pressable>;
        })}</View>
      </Surface>

      <View style={{ gap: spacing[2] }}>
        <SectionHeader title="Schedule filters" subtitle="Keep the view focused on one clinical resource" icon={Filter} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[2] }}><Chip label="All clinicians" selected={!doctorId} onPress={() => setDoctorId(undefined)} />{staffQuery.data?.filter((s) => s.role === 'dentist' || s.role === 'owner').map((s) => <Chip key={s.id} label={s.name} selected={doctorId === s.id} onPress={() => setDoctorId(s.id)} />)}</View>
      </View>

      {conflicts.length ? <Surface tone="danger" style={{ gap: spacing[2] }}><View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><View style={{ flex: 1 }}><AppText variant="bodyStrong">{conflicts.length} resource conflicts detected</AppText><AppText tone="secondary">Review chair overlap before confirming these visits.</AppText></View><Badge label="Resolve" tone="danger" /></View></Surface> : null}

      <Surface style={{ gap: 0 }}>
        <SectionHeader title={view === 'week' ? 'Week schedule' : 'Day schedule'} subtitle="Status-aware actions and visit readiness" icon={CalendarDays} actionLabel="New booking" onAction={() => router.push('/appointment/new')} />
        {appointmentsQuery.isLoading ? <LoadingState /> : appointmentsQuery.isError ? <ErrorState onRetry={() => appointmentsQuery.refetch()} /> : appointments.length === 0 ? <View style={{ paddingVertical: spacing[8], alignItems: 'center', gap: spacing[2] }}><AppText variant="title3">No visits scheduled</AppText><AppText tone="secondary">Use the open capacity for a waiting-list patient.</AppText></View> : appointments.map((item, index) => <View key={item.id}><AppointmentRow appointment={item} onPress={() => router.push(`/appointment/${item.id}`)} />{index < appointments.length - 1 ? <View style={{ height: 1, backgroundColor: theme.colors.border }} /> : null}</View>)}
      </Surface>
    </View>
    <FloatingAction label="Book appointment" icon={Plus} onPress={() => router.push('/appointment/new')} />
  </Screen>;
}
