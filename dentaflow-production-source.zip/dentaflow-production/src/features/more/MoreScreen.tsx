import React from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { Archive, BadgeIndianRupee, Bell, BookOpen, Box, Building2, ClipboardList, FileClock, FlaskConical, History, LayoutDashboard, ListChecks, LockKeyhole, Package, Settings, ShieldCheck, SlidersHorizontal, Stethoscope, UsersRound, WandSparkles } from '@/ui/icons';
import { AppText, PageHeader, PressableSurface, Screen, SectionHeader, Surface } from '@/ui/components';
import { spacing } from '@/ui/tokens';
import { useUIStore } from '@/store/uiStore';
import { useClinic } from '@/hooks/useClinicQueries';

const modules = [
  { title: 'Waiting room', detail: 'Check-in, queue, chair readiness and delays', icon: ListChecks, route: '/waiting-room' },
  { title: 'Billing', detail: 'Invoices, collections, refunds and aging', icon: BadgeIndianRupee, route: '/billing' },
  { title: 'Treatment pipeline', detail: 'Proposed care through completion', icon: Stethoscope, route: '/treatment-pipeline' },
  { title: 'Recall', detail: 'Due, overdue and inactive patients', icon: FileClock, route: '/recalls' },
  { title: 'Laboratory', detail: 'Cases, shades, trials, due dates and costs', icon: FlaskConical, route: '/laboratory' },
  { title: 'Inventory', detail: 'Stock, batches, expiry and reorder levels', icon: Package, route: '/inventory' },
  { title: 'Tasks', detail: 'Callbacks, handovers and clinical work', icon: ClipboardList, route: '/tasks' },
  { title: 'Reports', detail: 'Operations, production and collections', icon: LayoutDashboard, route: '/reports' }
] as const;
const control = [
  { title: 'Team and access', detail: 'Roles, invitations and permissions', icon: UsersRound, route: '/team' },
  { title: 'Branches and chairs', detail: 'Locations, rooms and active context', icon: Building2, route: '/branches' },
  { title: 'Family accounts', detail: 'Guardians, shared contacts and billing', icon: Archive, route: '/family' },
  { title: 'Automations', detail: 'Reminders, follow-ups and recare workflows', icon: WandSparkles, route: '/automations' },
  { title: 'Templates', detail: 'Clinical, consent and communication templates', icon: BookOpen, route: '/templates' },
  { title: 'Integrations', detail: 'Supabase, WhatsApp, email, phone and AI', icon: SlidersHorizontal, route: '/integrations' },
  { title: 'Audit log', detail: 'Immutable access and change history', icon: ShieldCheck, route: '/audit' },
  { title: 'Settings', detail: 'Clinic, privacy, devices and notifications', icon: Settings, route: '/settings' }
] as const;
export function MoreScreen() {
  const clinic = useClinic(); const setCommand = useUIStore((s) => s.setCommandOpen);
  return <Screen><PageHeader title="More" subtitle="Practice administration and clinical operations" onSearch={() => setCommand(true)} />
    <View style={{ paddingHorizontal: spacing[4], gap: spacing[5] }}>
      <Surface tone="clinical" style={{ gap: spacing[2] }}><AppText variant="title3">{clinic.data?.name ?? 'DentaFlow Clinic'}</AppText><AppText tone="secondary">Branch administration · Production mode ready</AppText></Surface>
      <View><SectionHeader title="Practice operations" subtitle="Daily systems outside the primary navigation" /> <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[3] }}>{modules.map((m) => <Module key={m.route} {...m} />)}</View></View>
      <View><SectionHeader title="Configuration and governance" subtitle="Control who can do what and how records move" /> <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[3] }}>{control.map((m) => <Module key={m.route} {...m} />)}</View></View>
    </View>
  </Screen>;
}
function Module({ title, detail, icon: Icon, route }: { title: string; detail: string; icon: typeof Archive; route: string }) { return <PressableSurface accessibilityLabel={title} onPress={() => router.push(route as never)} style={{ width: '48%', minHeight: 142, padding: spacing[4], gap: spacing[3] }}><Icon size={22} /><View style={{ gap: 3 }}><AppText variant="bodyStrong">{title}</AppText><AppText variant="caption" tone="secondary">{detail}</AppText></View></PressableSurface>; }
