import React, { useMemo } from 'react';
import { Pressable, RefreshControl, View } from 'react-native';
import { useRouter } from 'expo-router';
import {
  AlertCircle, BadgeIndianRupee, CalendarDays, CheckCircle2, Clock3, FlaskConical,
  Inbox, Phone, Plus, UserRoundPlus, UsersRound
} from '@/ui/icons';
import {
  AppText, AppointmentRow, Badge, Button, ErrorState, FloatingAction, ListRow, LoadingState,
  MetricTile, PageHeader, Screen, SectionHeader, Surface, TaskRow
} from '@/ui/components';
import { spacing, radii } from '@/ui/tokens';
import { useTheme } from '@/ui/ThemeProvider';
import { useDashboard, useSetTaskStatus, useTransitionAppointment } from '@/hooks/useClinicQueries';
import { useUIStore } from '@/store/uiStore';
import { getNextAppointmentActions } from '@/domain/rules';
import { APPOINTMENT_STATUS_LABELS } from '@/domain/constants';
import { money, relativeTime } from '@/core/format';
import type { Appointment } from '@/domain/types';

function nextOperationalStatus(appointment: Appointment) {
  const preferred = ['checked-in', 'waiting', 'in-chair', 'completed', 'needs-follow-up'] as const;
  return preferred.find((status) => getNextAppointmentActions(appointment.status).includes(status));
}

export function TodayScreen() {
  const theme = useTheme();
  const router = useRouter();
  const dashboard = useDashboard();
  const transition = useTransitionAppointment();
  const setTask = useSetTaskStatus();
  const setCommandOpen = useUIStore((state) => state.setCommandOpen);
  const showToast = useUIStore((state) => state.showToast);

  const actionItems = useMemo(() => {
    const data = dashboard.data;
    if (!data) return [];
    return [
      data.metrics.unconfirmed ? { id: 'unconfirmed', title: `${data.metrics.unconfirmed} appointment${data.metrics.unconfirmed === 1 ? '' : 's'} need confirmation`, subtitle: 'Contact patients before their slot is at risk', icon: CalendarDays, tone: 'warning' as const, route: '/(tabs)/calendar' } : null,
      data.metrics.missedCalls ? { id: 'calls', title: `${data.metrics.missedCalls} missed call${data.metrics.missedCalls === 1 ? '' : 's'} need callbacks`, subtitle: 'Potential patients should not be left waiting', icon: Phone, tone: 'danger' as const, route: '/(tabs)/inbox' } : null,
      data.overdueInvoices.length ? { id: 'billing', title: `${data.overdueInvoices.length} overdue account${data.overdueInvoices.length === 1 ? '' : 's'}`, subtitle: `${money(data.overdueInvoices.reduce((sum, item) => sum + item.balance, 0))} requires collection follow-up`, icon: BadgeIndianRupee, tone: 'warning' as const, route: '/(modules)/billing' } : null,
      data.labDue.length ? { id: 'lab', title: `${data.labDue.length} lab case${data.labDue.length === 1 ? '' : 's'} need attention`, subtitle: 'Verify delivery before dependent appointments', icon: FlaskConical, tone: 'danger' as const, route: '/(modules)/laboratory' } : null
    ].filter(Boolean) as Array<{ id: string; title: string; subtitle: string; icon: typeof CalendarDays; tone: 'warning' | 'danger'; route: string }>;
  }, [dashboard.data]);

  if (dashboard.isLoading) return <Screen><PageHeader title="Today" subtitle="Preparing your clinic command centre" /><LoadingState /></Screen>;
  if (dashboard.isError || !dashboard.data) return <Screen><PageHeader title="Today" /><ErrorState message={dashboard.error instanceof Error ? dashboard.error.message : undefined} onRetry={() => dashboard.refetch()} /></Screen>;
  const data = dashboard.data;

  const advance = async (appointment: Appointment) => {
    const status = nextOperationalStatus(appointment);
    if (!status) return router.push(`/appointment/${appointment.id}` as never);
    try {
      await transition.mutateAsync({ id: appointment.id, status });
      showToast(`Appointment moved to ${APPOINTMENT_STATUS_LABELS[status]}.`, 'success');
    } catch (error) { showToast(error instanceof Error ? error.message : 'Could not update appointment.', 'danger'); }
  };

  return <Screen refreshControl={<RefreshControl refreshing={dashboard.isRefetching} onRefresh={() => dashboard.refetch()} tintColor={theme.colors.clinical} />}>
    <PageHeader
      eyebrow={data.clinic.branchCode}
      title={`Good ${new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}, ${data.currentStaff.name.split(' ')[1] ?? data.currentStaff.name}`}
      subtitle={`${data.clinic.name} · ${data.clinic.openingTime}–${data.clinic.closingTime}`}
      onSearch={() => setCommandOpen(true)}
      onNotifications={() => router.push('/(tabs)/inbox')}
      notificationCount={data.metrics.missedCalls + data.metrics.unconfirmed}
    />

    <View style={{ paddingHorizontal: spacing[4], gap: spacing[6] }}>
      <Surface style={{ padding: 0, overflow: 'hidden' }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[3], padding: spacing[4], borderBottomWidth: 1, borderBottomColor: theme.colors.border }}>
          <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: theme.colors.success }} />
          <View style={{ flex: 1 }}><AppText variant="bodyStrong">Clinic is open</AppText><AppText variant="caption" tone="secondary">{data.waiting.length ? `${data.waiting.length} patients currently moving through reception and chairs` : 'No patient is waiting right now'}</AppText></View>
          <Badge label={new Date().toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })} tone="neutral" />
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[3], padding: spacing[4] }}>
          <MetricTile label="Appointments" value={data.metrics.appointmentsToday} icon={CalendarDays} tone="primary" />
          <MetricTile label="Waiting" value={data.metrics.waiting} icon={Clock3} tone={data.metrics.waiting ? 'warning' : 'success'} />
          <MetricTile label="In chair" value={data.metrics.inChair} icon={UsersRound} tone="clinical" />
          <MetricTile label="Collected today" value={money(data.metrics.collectionsToday)} icon={BadgeIndianRupee} tone="success" />
        </View>
      </Surface>

      <View>
        <SectionHeader title="Needs attention now" subtitle="Prioritised by time, patient risk, and revenue impact" />
        {actionItems.length ? <Surface padded={false}>
          {actionItems.map((item, index) => <View key={item.id} style={{ paddingHorizontal: spacing[4], borderBottomWidth: index < actionItems.length - 1 ? 1 : 0, borderBottomColor: theme.colors.border }}><ListRow title={item.title} subtitle={item.subtitle} icon={item.icon} iconTone={item.tone} onPress={() => router.push(item.route as never)} /></View>)}
        </Surface> : <Surface tone="success"><View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[3] }}><CheckCircle2 size={22} color={theme.colors.success} /><View style={{ flex: 1 }}><AppText variant="bodyStrong">No urgent administrative exceptions</AppText><AppText tone="secondary">The clinic is operating within today’s planned workflow.</AppText></View></View></Surface>}
      </View>

      <View>
        <SectionHeader title="Live clinic flow" subtitle="Move patients forward without opening a separate form" actionLabel="Full calendar" onAction={() => router.push('/(tabs)/calendar')} />
        <Surface padded={false}>
          {data.appointments.length ? data.appointments.map((appointment, index) => {
            const next = nextOperationalStatus(appointment);
            return <View key={appointment.id} style={{ paddingHorizontal: spacing[4], borderBottomWidth: index < data.appointments.length - 1 ? 1 : 0, borderBottomColor: theme.colors.border }}><AppointmentRow appointment={appointment} onPress={() => router.push(`/appointment/${appointment.id}` as never)} onPrimaryAction={next ? () => advance(appointment) : undefined} primaryActionLabel={next ? APPOINTMENT_STATUS_LABELS[next] : undefined} /></View>;
          }) : <View style={{ padding: spacing[6], alignItems: 'center', gap: spacing[2] }}><CalendarDays size={24} color={theme.colors.textMuted} /><AppText variant="bodyStrong">No appointments today</AppText><AppText tone="secondary">Book an appointment or open the waiting list.</AppText></View>}
        </Surface>
      </View>

      <View>
        <SectionHeader title="Team handovers" subtitle="Open work that can block patient flow" actionLabel="View all" onAction={() => router.push('/(modules)/tasks')} />
        <Surface padded={false}>
          {data.tasks.slice(0, 5).map((task, index) => <View key={task.id} style={{ paddingHorizontal: spacing[4], borderBottomWidth: index < Math.min(5, data.tasks.length) - 1 ? 1 : 0, borderBottomColor: theme.colors.border }}><TaskRow task={task} onPress={async () => { if (task.status === 'open') { await setTask.mutateAsync({ id: task.id, status: 'in-progress' }); showToast('Task assigned to your active queue.', 'success'); } else router.push('/(modules)/tasks'); }} /></View>)}
        </Surface>
      </View>

      <View>
        <SectionHeader title="Quick work" subtitle="Frequent actions kept close, secondary tools kept out of the tab bar" />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[3] }}>
          {[
            { label: 'New patient', icon: UserRoundPlus, route: '/patient/new' },
            { label: 'Book visit', icon: CalendarDays, route: '/appointment/new' },
            { label: 'Waiting room', icon: UsersRound, route: '/(modules)/waiting-room' },
            { label: 'Inbox', icon: Inbox, route: '/(tabs)/inbox' }
          ].map((item) => <Pressable key={item.label} accessibilityRole="button" accessibilityLabel={item.label} onPress={() => router.push(item.route as never)} style={({ pressed }) => ({ width: '47.8%', minHeight: 92, borderRadius: radii.lg, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border, padding: spacing[4], gap: spacing[3], opacity: pressed ? 0.68 : 1 })}><item.icon size={21} color={theme.colors.primary} /><AppText variant="bodyStrong">{item.label}</AppText></Pressable>)}
        </View>
      </View>

      <Surface tone="secondary">
        <View style={{ flexDirection: 'row', gap: spacing[3], alignItems: 'flex-start' }}><AlertCircle size={20} color={theme.colors.info} /><View style={{ flex: 1, gap: 2 }}><AppText variant="bodyStrong">Morning brief</AppText><AppText tone="secondary">{data.metrics.appointmentsToday} appointments, {data.metrics.unconfirmed} unconfirmed, {data.metrics.missedCalls} missed calls, {data.labDue.length} lab exceptions, and {money(data.metrics.outstanding)} total outstanding.</AppText><AppText variant="caption" tone="muted">Updated {relativeTime(new Date().toISOString())}</AppText></View></View>
      </Surface>
    </View>
    <FloatingAction label="New appointment" icon={Plus} onPress={() => router.push('/appointment/new')} />
  </Screen>;
}
