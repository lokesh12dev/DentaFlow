import React, { useMemo } from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { differenceInMinutes, parseISO } from 'date-fns';
import { useAppointments, useTransitionAppointment } from '@/hooks/useClinicQueries';
import { useUIStore } from '@/store/uiStore';
import { APPOINTMENT_STATUS_LABELS } from '@/domain/constants';
import { AppointmentRow, AppText, Badge, Button, EmptyState, ErrorState, LoadingState, MetricTile, PageHeader, Screen, SectionHeader, Surface } from '@/ui/components';
import { CheckCircle2, Clock3, ListChecks, Stethoscope, TriangleAlert, UserRound } from '@/ui/icons';
import { spacing } from '@/ui/tokens';
import { useTheme } from '@/ui/ThemeProvider';

export function WaitingRoomScreen() {
  const theme = useTheme(); const query = useAppointments({ date: new Date().toISOString().slice(0,10) }); const transition = useTransitionAppointment(); const toast = useUIStore((s) => s.showToast);
  const queue = useMemo(() => (query.data ?? []).filter((a) => ['checked-in','waiting','in-chair'].includes(a.status)).sort((a,b) => (a.checkedInAt ?? a.startsAt).localeCompare(b.checkedInAt ?? b.startsAt)), [query.data]);
  const waiting = queue.filter((a) => a.status === 'checked-in' || a.status === 'waiting'); const inChair = queue.filter((a) => a.status === 'in-chair');
  const delayed = waiting.filter((a) => differenceInMinutes(new Date(), parseISO(a.startsAt)) > 15);
  const move = async (id: string, status: 'waiting'|'in-chair'|'completed') => { try { await transition.mutateAsync({ id, status }); toast(`Patient moved to ${APPOINTMENT_STATUS_LABELS[status]}`, 'success'); } catch (e) { toast(e instanceof Error ? e.message : 'Unable to move patient', 'danger'); } };
  return <Screen><PageHeader title="Waiting room" subtitle="Live reception-to-chair patient flow" onBack={() => router.back()} />
    <View style={{ paddingHorizontal: spacing[4], gap: spacing[4] }}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[3] }}><MetricTile label="Checked in" value={String(waiting.length)} icon={UserRound} tone="primary" /><MetricTile label="In chair" value={String(inChair.length)} icon={Stethoscope} tone="clinical" /><MetricTile label="Delayed" value={String(delayed.length)} icon={TriangleAlert} tone={delayed.length ? 'danger' : 'success'} /></View>
      {delayed.length ? <Surface tone="danger" style={{ gap: spacing[2] }}><AppText variant="bodyStrong">Reception intervention required</AppText><AppText tone="secondary">{delayed.map((a) => a.patientName).join(', ')} {delayed.length === 1 ? 'has' : 'have'} waited more than 15 minutes.</AppText></Surface> : null}
      {query.isLoading ? <LoadingState /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : queue.length === 0 ? <EmptyState title="No patients in clinic" message="Checked-in patients will appear here with readiness and chair actions." icon={ListChecks} /> : <>
        <Surface style={{ gap: 0 }}><SectionHeader title="Reception queue" subtitle="Oldest checked-in patient first" icon={Clock3} />{waiting.length ? waiting.map((a, i) => <View key={a.id}><AppointmentRow appointment={a} onPress={() => router.push(`/appointment/${a.id}`)} onPrimaryAction={() => move(a.id, a.status === 'checked-in' ? 'waiting' : 'in-chair')} primaryActionLabel={a.status === 'checked-in' ? 'Mark waiting' : 'Move to chair'} />{i < waiting.length - 1 ? <View style={{ height: 1, backgroundColor: theme.colors.border }} /> : null}</View>) : <AppText tone="secondary">No one is waiting.</AppText>}</Surface>
        <Surface style={{ gap: 0 }}><SectionHeader title="Active chairs" subtitle="Visits currently under treatment" icon={Stethoscope} />{inChair.length ? inChair.map((a, i) => <View key={a.id}><AppointmentRow appointment={a} onPress={() => router.push(`/appointment/${a.id}`)} onPrimaryAction={() => move(a.id,'completed')} primaryActionLabel="Complete visit" />{i < inChair.length - 1 ? <View style={{ height: 1, backgroundColor: theme.colors.border }} /> : null}</View>) : <AppText tone="secondary">All chairs are available.</AppText>}</Surface>
      </>}
      <Surface tone="clinical" style={{ gap: spacing[2] }}><View style={{ flexDirection:'row',alignItems:'center',gap:spacing[3] }}><CheckCircle2 size={20} color={theme.colors.clinical}/><View style={{flex:1}}><AppText variant="bodyStrong">Reception handover rule</AppText><AppText tone="secondary">A patient only leaves this queue after chair acceptance or documented cancellation.</AppText></View></View></Surface>
    </View>
  </Screen>;
}
