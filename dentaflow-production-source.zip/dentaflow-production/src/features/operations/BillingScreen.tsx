import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { router } from 'expo-router';
import { useInvoices, usePatients } from '@/hooks/useClinicQueries';
import { money, relativeTime } from '@/core/format';
import { AppText, Badge, Button, Chip, EmptyState, ErrorState, LoadingState, MetricTile, PageHeader, Screen, SectionHeader, Surface } from '@/ui/components';
import { BadgeIndianRupee, CircleDollarSign, Clock3, CreditCard, Receipt, TriangleAlert } from '@/ui/icons';
import { spacing } from '@/ui/tokens';
import { useTheme } from '@/ui/ThemeProvider';

export function BillingScreen() {
  const theme=useTheme(); const invoices=useInvoices(); const patients=usePatients(); const [filter,setFilter]=useState<'outstanding'|'overdue'|'paid'|'all'>('outstanding');
  const rows=useMemo(()=>(invoices.data??[]).filter(i=>filter==='all'||(filter==='outstanding'&&i.balance>0)||(filter==='overdue'&&i.status==='overdue')||(filter==='paid'&&i.status==='paid')), [invoices.data,filter]);
  const outstanding=(invoices.data??[]).reduce((s,i)=>s+i.balance,0); const overdue=(invoices.data??[]).filter(i=>i.status==='overdue').reduce((s,i)=>s+i.balance,0); const collected=(invoices.data??[]).reduce((s,i)=>s+i.paid,0);
  return <Screen><PageHeader title="Billing" subtitle="Receivables, collections and patient ledger control" onBack={()=>router.back()} />
    <View style={{paddingHorizontal:spacing[4],gap:spacing[4]}}>
      <View style={{flexDirection:'row',flexWrap:'wrap',gap:spacing[3]}}><MetricTile label="Outstanding" value={money(outstanding)} icon={BadgeIndianRupee} tone="warning"/><MetricTile label="Overdue" value={money(overdue)} icon={TriangleAlert} tone={overdue?'danger':'success'}/><MetricTile label="Recorded paid" value={money(collected)} icon={CircleDollarSign} tone="success"/></View>
      <Surface style={{gap:spacing[3]}}><SectionHeader title="Ledger filter" subtitle="Separate action queues from historical records" icon={CreditCard}/><View style={{flexDirection:'row',flexWrap:'wrap',gap:spacing[2]}}>{(['outstanding','overdue','paid','all'] as const).map(f=><Chip key={f} label={f[0]!.toUpperCase()+f.slice(1)} selected={filter===f} onPress={()=>setFilter(f)}/>)}</View></Surface>
      <Surface style={{gap:0}}><SectionHeader title="Invoices" subtitle={`${rows.length} records`} icon={Receipt} actionLabel="Record payment" onAction={()=>router.push('/payment/new')}/>{invoices.isLoading?<LoadingState/>:invoices.isError?<ErrorState onRetry={()=>invoices.refetch()}/>:!rows.length?<EmptyState title="No invoices" message="No invoices match the selected status." icon={Receipt}/>:rows.map((invoice,index)=>{const patient=patients.data?.find(p=>p.id===invoice.patientId);return <View key={invoice.id}><Pressable accessibilityRole="button" accessibilityLabel={`${invoice.invoiceNumber} for ${patient?.displayName??'patient'}`} onPress={()=>router.push({pathname:'/payment/new',params:{patientId:invoice.patientId,invoiceId:invoice.id}})} style={({pressed})=>({paddingVertical:spacing[4],opacity:pressed?.68:1})}><View style={{flexDirection:'row',gap:spacing[3]}}><View style={{width:44,height:44,borderRadius:14,backgroundColor:invoice.status==='overdue'?theme.colors.dangerSoft:theme.colors.primarySoft,alignItems:'center',justifyContent:'center'}}><Receipt size={19} color={invoice.status==='overdue'?theme.colors.danger:theme.colors.primary}/></View><View style={{flex:1,gap:3}}><View style={{flexDirection:'row',gap:spacing[2]}}><AppText variant="bodyStrong" style={{flex:1}}>{patient?.displayName??invoice.patientId}</AppText><Badge label={invoice.status} tone={invoice.status==='paid'?'success':invoice.status==='overdue'?'danger':'warning'}/></View><AppText variant="caption" tone="secondary">{invoice.invoiceNumber} · {relativeTime(invoice.issuedAt)}</AppText><View style={{flexDirection:'row',justifyContent:'space-between'}}><AppText>{money(invoice.total)} total</AppText><AppText variant="bodyStrong" style={{color:invoice.balance>0?theme.colors.warning:theme.colors.success}}>{money(invoice.balance)} due</AppText></View></View></View></Pressable>{index<rows.length-1?<View style={{height:1,backgroundColor:theme.colors.border}}/>:null}</View>})}</Surface>
      <Button label="Record a payment" icon={BadgeIndianRupee} onPress={()=>router.push('/payment/new')} full/>
    </View>
  </Screen>;
}
