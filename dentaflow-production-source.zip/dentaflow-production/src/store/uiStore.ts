import { create } from 'zustand';

type ToastTone = 'success' | 'warning' | 'danger' | 'neutral';

interface ToastState {
  id: number;
  message: string;
  tone: ToastTone;
}

interface UIState {
  toast: ToastState | null;
  commandOpen: boolean;
  showToast: (message: string, tone?: ToastTone) => void;
  hideToast: () => void;
  setCommandOpen: (open: boolean) => void;
}

export const useUIStore = create<UIState>((set) => ({
  toast: null,
  commandOpen: false,
  showToast: (message, tone = 'neutral') => {
    const id = Date.now();
    set({ toast: { id, message, tone } });
    setTimeout(() => set((state) => state.toast?.id === id ? { toast: null } : state), 3200);
  },
  hideToast: () => set({ toast: null }),
  setCommandOpen: (commandOpen) => set({ commandOpen })
}));
