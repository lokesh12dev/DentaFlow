import * as SecureStore from 'expo-secure-store';

const PREFIX = 'dentaflow:';
const CHUNK_SIZE = 1800;
const options: SecureStore.SecureStoreOptions = { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY };
const fullKey = (key: string) => `${PREFIX}${key}`;
const manifestKey = (key: string) => `${fullKey(key)}:chunks`;
const chunkKey = (key: string, index: number) => `${fullKey(key)}:${index}`;

async function existingChunkCount(key: string): Promise<number> {
  const value = await SecureStore.getItemAsync(manifestKey(key));
  const count = Number(value ?? 0);
  return Number.isSafeInteger(count) && count > 0 ? count : 0;
}

export const secureStorage = {
  async get(key: string): Promise<string | null> {
    try {
      const count = await existingChunkCount(key);
      if (!count) return await SecureStore.getItemAsync(fullKey(key));
      const chunks = await Promise.all(Array.from({ length: count }, (_, index) => SecureStore.getItemAsync(chunkKey(key, index))));
      if (chunks.some((chunk) => chunk == null)) return null;
      return chunks.join('');
    } catch { return null; }
  },
  async set(key: string, value: string): Promise<void> {
    const previousChunks = await existingChunkCount(key);
    if (value.length <= CHUNK_SIZE) {
      await SecureStore.setItemAsync(fullKey(key), value, options);
      await SecureStore.deleteItemAsync(manifestKey(key));
      await Promise.all(Array.from({ length: previousChunks }, (_, index) => SecureStore.deleteItemAsync(chunkKey(key, index))));
      return;
    }
    const chunks = Array.from({ length: Math.ceil(value.length / CHUNK_SIZE) }, (_, index) => value.slice(index * CHUNK_SIZE, (index + 1) * CHUNK_SIZE));
    await Promise.all(chunks.map((chunk, index) => SecureStore.setItemAsync(chunkKey(key, index), chunk, options)));
    await SecureStore.setItemAsync(manifestKey(key), String(chunks.length), options);
    await SecureStore.deleteItemAsync(fullKey(key));
    if (previousChunks > chunks.length) await Promise.all(Array.from({ length: previousChunks - chunks.length }, (_, offset) => SecureStore.deleteItemAsync(chunkKey(key, chunks.length + offset))));
  },
  async remove(key: string): Promise<void> {
    const count = await existingChunkCount(key);
    await Promise.all([
      SecureStore.deleteItemAsync(fullKey(key)),
      SecureStore.deleteItemAsync(manifestKey(key)),
      ...Array.from({ length: count }, (_, index) => SecureStore.deleteItemAsync(chunkKey(key, index)))
    ]);
  }
};

export const supabaseAuthStorage = {
  getItem: (key: string) => secureStorage.get(`auth:${key}`),
  setItem: (key: string, value: string) => secureStorage.set(`auth:${key}`, value),
  removeItem: (key: string) => secureStorage.remove(`auth:${key}`)
};
