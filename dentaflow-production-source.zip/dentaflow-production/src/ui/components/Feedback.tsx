import React, { useEffect, useRef } from 'react';
import { ActivityIndicator, Animated, Pressable, View } from 'react-native';
import { AlertCircle, CheckCircle2, RefreshCw } from '../icons';
import { radii, shadows, spacing } from '../tokens';
import { useTheme } from '../ThemeProvider';
import { AppText } from './Typography';
import { Button } from './Button';
import { useUIStore } from '@/store/uiStore';

export function LoadingState({ label = 'Loading clinic data…' }: { label?: string }) {
  const theme = useTheme();
  return <View style={{ flex: 1, minHeight: 220, alignItems: 'center', justifyContent: 'center', gap: spacing[3] }}><ActivityIndicator size="small" color={theme.colors.clinical} /><AppText tone="secondary">{label}</AppText></View>;
}

export function ErrorState({ title = 'Unable to load this view', message, onRetry }: { title?: string; message?: string; onRetry?: () => void }) {
  const theme = useTheme();
  return <View style={{ minHeight: 240, alignItems: 'center', justifyContent: 'center', padding: spacing[6], gap: spacing[3] }}>
    <View style={{ width: 52, height: 52, borderRadius: 18, backgroundColor: theme.colors.dangerSoft, alignItems: 'center', justifyContent: 'center' }}><AlertCircle size={24} color={theme.colors.danger} /></View>
    <AppText variant="title3" style={{ textAlign: 'center' }}>{title}</AppText>
    {message ? <AppText tone="secondary" style={{ textAlign: 'center' }}>{message}</AppText> : null}
    {onRetry ? <Button label="Try again" tone="secondary" icon={RefreshCw} onPress={onRetry} /> : null}
  </View>;
}

export function EmptyState({ title, message, actionLabel, onAction, icon: Icon = CheckCircle2 }: { title: string; message: string; actionLabel?: string; onAction?: () => void; icon?: typeof CheckCircle2 }) {
  const theme = useTheme();
  return <View style={{ minHeight: 220, alignItems: 'center', justifyContent: 'center', padding: spacing[6], gap: spacing[3] }}>
    <View style={{ width: 52, height: 52, borderRadius: 18, backgroundColor: theme.colors.surfaceTertiary, alignItems: 'center', justifyContent: 'center' }}><Icon size={24} color={theme.colors.textSecondary} /></View>
    <AppText variant="title3" style={{ textAlign: 'center' }}>{title}</AppText>
    <AppText tone="secondary" style={{ textAlign: 'center', maxWidth: 330 }}>{message}</AppText>
    {actionLabel && onAction ? <Button label={actionLabel} onPress={onAction} /> : null}
  </View>;
}

export function Skeleton({ width = '100%', height = 18, radius = 8 }: { width?: number | `${number}%`; height?: number; radius?: number }) {
  const theme = useTheme();
  const opacity = useRef(new Animated.Value(0.45)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([Animated.timing(opacity, { toValue: 0.9, duration: 700, useNativeDriver: true }), Animated.timing(opacity, { toValue: 0.45, duration: 700, useNativeDriver: true })]));
    loop.start(); return () => loop.stop();
  }, [opacity]);
  return <Animated.View style={{ width, height, borderRadius: radius, backgroundColor: theme.colors.surfaceTertiary, opacity }} />;
}

export function ToastHost() {
  const toast = useUIStore((state) => state.toast);
  const hide = useUIStore((state) => state.hideToast);
  const theme = useTheme();
  if (!toast) return null;
  const color = toast.tone === 'danger' ? theme.colors.danger : toast.tone === 'warning' ? theme.colors.warning : toast.tone === 'success' ? theme.colors.success : theme.colors.primary;
  return <Pressable accessibilityRole="button" accessibilityLabel="Dismiss notification" onPress={hide} style={[{ position: 'absolute', left: spacing[4], right: spacing[4], bottom: 104, minHeight: 52, borderRadius: radii.lg, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border, flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing[4], gap: spacing[3], zIndex: 1000 }, shadows.floating]}>
    <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color }} />
    <AppText variant="bodyStrong" style={{ flex: 1 }}>{toast.message}</AppText>
  </Pressable>;
}
