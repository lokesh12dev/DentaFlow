import React from 'react';
import { ScrollView, View, type ScrollViewProps, type StyleProp, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { spacing } from '../tokens';
import { useTheme } from '../ThemeProvider';

export function Screen({ children, scroll = true, contentContainerStyle, style, bottomInset = true, ...props }: ScrollViewProps & { children: React.ReactNode; scroll?: boolean; contentContainerStyle?: StyleProp<ViewStyle>; bottomInset?: boolean }) {
  const theme = useTheme();
  const bodyStyle = [{ flexGrow: 1, paddingBottom: bottomInset ? 112 : spacing[6] }, contentContainerStyle];
  return <SafeAreaView edges={['top', 'left', 'right']} style={[{ flex: 1, backgroundColor: theme.colors.canvas }, style]}>
    {scroll ? <ScrollView {...props} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={bodyStyle}>{children}</ScrollView> : <View style={[{ flex: 1 }, contentContainerStyle]}>{children}</View>}
  </SafeAreaView>;
}
