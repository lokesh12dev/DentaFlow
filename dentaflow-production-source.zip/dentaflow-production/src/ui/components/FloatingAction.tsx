import React from 'react';
import { Pressable, View } from 'react-native';
import type { LucideIcon } from '../icons';
import { Plus } from '../icons';
import { radii, shadows, sizes, spacing } from '../tokens';
import { useTheme } from '../ThemeProvider';
import { AppText } from './Typography';
import { haptics } from '@/core/haptics';

export function FloatingAction({ label, onPress, icon: Icon = Plus, compact = false }: { label: string; onPress: () => void; icon?: LucideIcon; compact?: boolean }) {
  const theme = useTheme();
  return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={() => { haptics.impact(); onPress(); }} style={({ pressed }) => [{ position: 'absolute', right: spacing[4], bottom: 102, height: sizes.touchLarge, minWidth: sizes.touchLarge, borderRadius: radii.pill, paddingHorizontal: compact ? 0 : spacing[4], backgroundColor: theme.colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing[2], opacity: pressed ? 0.84 : 1, transform: [{ scale: pressed ? 0.98 : 1 }], zIndex: 70 }, shadows.floating]}>
    <Icon size={21} color={theme.colors.textInverse} strokeWidth={2.2} />
    {!compact ? <AppText variant="label" tone="inverse">{label}</AppText> : null}
  </Pressable>;
}
