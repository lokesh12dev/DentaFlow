import React from 'react';
import { Platform, Pressable, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { CalendarDays, Home, Inbox, MoreHorizontal, UsersRound, type LucideIcon } from '../icons';
import { radii, shadows, sizes, spacing } from '../tokens';
import { useTheme } from '../ThemeProvider';
import { AppText } from './Typography';
import { haptics } from '@/core/haptics';

const tabIcons: Record<string, LucideIcon> = { today: Home, patients: UsersRound, calendar: CalendarDays, inbox: Inbox, more: MoreHorizontal };

export function GlassTabBar({ state, descriptors, navigation }: any) {
  const theme = useTheme();
  const content = <View style={{ height: sizes.tabBar, flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing[2], borderRadius: radii.xxl, borderWidth: 1, borderColor: theme.colors.borderStrong, overflow: 'hidden' }}>
    {state.routes.map((route: any, index: number) => {
      const focused = state.index === index;
      const label = descriptors[route.key]?.options?.tabBarLabel ?? descriptors[route.key]?.options?.title ?? route.name;
      const Icon = tabIcons[route.name] ?? MoreHorizontal;
      return <Pressable key={route.key} accessibilityRole="tab" accessibilityState={{ selected: focused }} accessibilityLabel={String(label)} onPress={() => { haptics.selection(); const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true }); if (!focused && !event.defaultPrevented) navigation.navigate(route.name, route.params); }} onLongPress={() => navigation.emit({ type: 'tabLongPress', target: route.key })} style={({ pressed }) => ({ flex: 1, height: 56, alignItems: 'center', justifyContent: 'center', gap: 4, opacity: pressed ? 0.62 : 1 })}>
        <View style={{ width: 40, height: 30, borderRadius: 15, backgroundColor: focused ? theme.colors.primarySoft : 'transparent', alignItems: 'center', justifyContent: 'center' }}><Icon size={20} color={focused ? theme.colors.primary : theme.colors.textMuted} strokeWidth={focused ? 2.4 : 2} /></View>
        <AppText variant="tiny" style={{ color: focused ? theme.colors.primary : theme.colors.textMuted }}>{String(label)}</AppText>
      </Pressable>;
    })}
  </View>;
  return <View pointerEvents="box-none" style={{ position: 'absolute', left: spacing[4], right: spacing[4], bottom: Platform.OS === 'ios' ? 24 : 16, zIndex: 80 }}>
    {Platform.OS === 'ios' ? <BlurView intensity={55} tint={theme.dark ? 'dark' : 'light'} style={[{ borderRadius: radii.xxl, backgroundColor: theme.colors.glass, overflow: 'hidden' }, shadows.floating]}>{content}</BlurView> : <View style={[{ borderRadius: radii.xxl, backgroundColor: theme.colors.glass }, shadows.floating]}>{content}</View>}
  </View>;
}
