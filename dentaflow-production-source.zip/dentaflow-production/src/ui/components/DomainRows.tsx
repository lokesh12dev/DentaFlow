import React from 'react';
import { Pressable, View } from 'react-native';
import { AlertCircle, CalendarDays, CheckCircle2, Clock3, HeartPulse, BadgeIndianRupee, Mail, MessageCircle, Phone, UserRound } from '../icons';
import { APPOINTMENT_STATUS_LABELS } from '@/domain/constants';
import type { Appointment, Communication, Patient, Task } from '@/domain/types';
import { money, relativeTime, time } from '@/core/format';
import { radii, spacing } from '../tokens';
import { useTheme } from '../ThemeProvider';
import { AppText } from './Typography';
import { Avatar } from './ListRow';
import { Badge } from './Badge';
import { ProgressBar } from './Metric';
import { readinessScore } from '@/domain/rules';

function appointmentTone(status: Appointment['status']) {
  if (status === 'completed') return 'success' as const;
  if (status === 'cancelled' || status === 'no-show') return 'danger' as const;
  if (status === 'waiting' || status === 'checked-in' || status === 'awaiting-confirmation') return 'warning' as const;
  if (status === 'in-chair') return 'clinical' as const;
  return 'info' as const;
}

export function AppointmentRow({ appointment, onPress, onPrimaryAction, primaryActionLabel }: { appointment: Appointment; onPress: () => void; onPrimaryAction?: () => void; primaryActionLabel?: string }) {
  const theme = useTheme();
  const score = readinessScore(appointment.readiness);
  return <Pressable accessibilityRole="button" accessibilityLabel={`${appointment.patientName}, ${appointment.procedureName}, ${time(appointment.startsAt)}`} onPress={onPress} style={({ pressed }) => ({ paddingVertical: spacing[3], opacity: pressed ? 0.68 : 1 })}>
    <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: spacing[3] }}>
      <View style={{ width: 54, alignItems: 'center', gap: 2, paddingTop: 2 }}><AppText variant="bodyStrong">{time(appointment.startsAt).replace(' ', '\n')}</AppText><AppText variant="tiny" tone="muted">{appointment.durationMinutes}m</AppText></View>
      <View style={{ width: 3, alignSelf: 'stretch', minHeight: 62, borderRadius: 2, backgroundColor: appointment.status === 'in-chair' ? theme.colors.clinical : appointment.status === 'waiting' ? theme.colors.warning : appointment.status === 'confirmed' ? theme.colors.info : theme.colors.borderStrong }} />
      <View style={{ flex: 1, gap: spacing[2] }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[2] }}><AppText variant="bodyStrong" style={{ flex: 1 }} numberOfLines={1}>{appointment.patientName}</AppText><Badge label={APPOINTMENT_STATUS_LABELS[appointment.status]} tone={appointmentTone(appointment.status)} /></View>
        <AppText tone="secondary" numberOfLines={1}>{appointment.procedureName}</AppText>
        <AppText variant="caption" tone="muted">{appointment.doctorName} · {appointment.chairName}</AppText>
        {score < 100 ? <ProgressBar value={score} tone={score < 50 ? 'danger' : 'warning'} label="Visit readiness" /> : null}
        {onPrimaryAction && primaryActionLabel ? <Pressable accessibilityRole="button" accessibilityLabel={primaryActionLabel} onPress={(event) => { event.stopPropagation(); onPrimaryAction(); }} style={({ pressed }) => ({ alignSelf: 'flex-start', minHeight: 36, paddingHorizontal: spacing[3], borderRadius: radii.pill, backgroundColor: theme.colors.primarySoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.68 : 1 })}><AppText variant="caption" style={{ color: theme.colors.primary }}>{primaryActionLabel}</AppText></Pressable> : null}
      </View>
    </View>
  </Pressable>;
}

export function PatientRow({ patient, onPress }: { patient: Patient; onPress: () => void }) {
  const theme = useTheme();
  const critical = patient.medicalAlerts.some((alert) => alert.severity === 'critical' || alert.severity === 'high');
  return <Pressable accessibilityRole="button" accessibilityLabel={`Open ${patient.displayName}`} onPress={onPress} style={({ pressed }) => ({ paddingVertical: spacing[3], opacity: pressed ? 0.65 : 1 })}>
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[3] }}>
      <Avatar name={patient.displayName} tone={critical ? 'danger' : 'clinical'} />
      <View style={{ flex: 1, gap: 3 }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[2] }}><AppText variant="bodyStrong" style={{ flexShrink: 1 }} numberOfLines={1}>{patient.displayName}</AppText>{critical ? <HeartPulse size={16} color={theme.colors.danger} /> : null}</View><AppText variant="caption" tone="secondary">{patient.patientNumber} · {patient.age} years · {patient.phone}</AppText><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing[1] }}>{patient.balance > 0 ? <Badge label={`${money(patient.balance)} due`} tone="warning" /> : null}{!patient.intakeVerified ? <Badge label="Intake review" tone="danger" /> : null}{patient.recallStatus === 'overdue' ? <Badge label="Recall overdue" tone="warning" /> : null}{patient.activeTreatmentStage ? <Badge label={patient.activeTreatmentStage.replaceAll('-', ' ')} tone="clinical" /> : null}</View></View>
    </View>
  </Pressable>;
}

export function CommunicationRow({ communication, onPress }: { communication: Communication; onPress: () => void }) {
  const theme = useTheme();
  const Icon = communication.channel === 'call' ? Phone : communication.channel === 'whatsapp' ? MessageCircle : communication.channel === 'email' ? Mail : MessageCircle;
  const failed = communication.status === 'failed' || communication.status === 'missed';
  return <Pressable accessibilityRole="button" accessibilityLabel={`Open ${communication.channel} from ${communication.patientName ?? communication.phone ?? 'unknown contact'}`} onPress={onPress} style={({ pressed }) => ({ paddingVertical: spacing[3], opacity: pressed ? 0.65 : 1 })}>
    <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: spacing[3] }}><View style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: failed ? theme.colors.dangerSoft : theme.colors.infoSoft, alignItems: 'center', justifyContent: 'center' }}><Icon size={19} color={failed ? theme.colors.danger : theme.colors.info} /></View><View style={{ flex: 1, gap: 3 }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[2] }}><AppText variant="bodyStrong" style={{ flex: 1 }} numberOfLines={1}>{communication.patientName ?? communication.phone ?? communication.email ?? 'Unknown contact'}</AppText>{communication.unread ? <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: theme.colors.clinical }} /> : null}</View><AppText tone="secondary" numberOfLines={2}>{communication.body ?? communication.subject ?? communication.callOutcome ?? (communication.status === 'missed' ? 'Missed call' : 'Communication logged')}</AppText><AppText variant="caption" tone="muted">{communication.channel} · {relativeTime(communication.occurredAt)}</AppText></View></View>
  </Pressable>;
}

export function TaskRow({ task, onPress }: { task: Task; onPress: () => void }) {
  const theme = useTheme();
  const urgent = task.priority === 'urgent' || task.priority === 'high';
  const Icon = task.category === 'callback' ? Phone : task.category === 'payment' ? BadgeIndianRupee : task.category === 'clinical' ? HeartPulse : task.category === 'recall' ? CalendarDays : task.category === 'inventory' ? AlertCircle : CheckCircle2;
  return <Pressable accessibilityRole="button" accessibilityLabel={`${task.title}, ${task.priority} priority`} onPress={onPress} style={({ pressed }) => ({ paddingVertical: spacing[3], opacity: pressed ? 0.65 : 1 })}>
    <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: spacing[3] }}><View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: urgent ? theme.colors.warningSoft : theme.colors.surfaceTertiary, alignItems: 'center', justifyContent: 'center' }}><Icon size={18} color={urgent ? theme.colors.warning : theme.colors.textSecondary} /></View><View style={{ flex: 1, gap: 3 }}><AppText variant="bodyStrong">{task.title}</AppText>{task.description ? <AppText tone="secondary" numberOfLines={2}>{task.description}</AppText> : null}<View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing[2] }}><Badge label={task.priority} tone={task.priority === 'urgent' ? 'danger' : task.priority === 'high' ? 'warning' : 'neutral'} /><AppText variant="caption" tone="muted">{task.assignedToName}{task.dueAt ? ` · ${relativeTime(task.dueAt)}` : ''}</AppText></View></View></View>
  </Pressable>;
}
