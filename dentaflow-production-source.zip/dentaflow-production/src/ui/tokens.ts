import { Platform } from 'react-native';

export const palette = {
  canvas: '#F4F5F7',
  canvasDark: '#0F1216',
  surface: '#FFFFFF',
  surfaceSecondary: '#F8F9FA',
  surfaceTertiary: '#EEF1F3',
  surfaceDark: '#171B20',
  surfaceDarkSecondary: '#1E2329',
  text: '#17191C',
  textSecondary: '#646A73',
  textMuted: '#9298A1',
  textInverse: '#FFFFFF',
  textDark: '#F4F6F8',
  textDarkSecondary: '#AAB0B8',
  border: '#E4E7EB',
  borderStrong: '#D5D9DE',
  borderDark: '#2D333A',
  navy: '#18324A',
  navyPressed: '#10283D',
  navySoft: '#E8EEF3',
  teal: '#167D78',
  tealPressed: '#0F6965',
  tealSoft: '#E8F4F2',
  blue: '#3E70A8',
  blueSoft: '#EAF0F7',
  green: '#26845B',
  greenSoft: '#E8F4ED',
  amber: '#A96E16',
  amberSoft: '#F8F0E2',
  red: '#C94A4A',
  redSoft: '#FAEAEA',
  rose: '#9C5264',
  roseSoft: '#F6EBEE',
  overlay: 'rgba(12, 18, 24, 0.42)',
  glass: 'rgba(255,255,255,0.82)',
  glassDark: 'rgba(23,27,32,0.86)'
} as const;

export const spacing = { 0: 0, 1: 4, 2: 8, 3: 12, 4: 16, 5: 20, 6: 24, 7: 28, 8: 32, 10: 40, 12: 48, 16: 64 } as const;
export const radii = { xs: 8, sm: 10, md: 12, lg: 16, xl: 20, xxl: 28, pill: 999 } as const;
export const sizes = { touch: 44, touchLarge: 52, input: 50, tabBar: 68, iconSm: 16, iconMd: 20, iconLg: 24 } as const;
export const typography = {
  display: { fontSize: 30, lineHeight: 36, fontWeight: '700' as const, letterSpacing: -0.8 },
  title1: { fontSize: 24, lineHeight: 30, fontWeight: '700' as const, letterSpacing: -0.4 },
  title2: { fontSize: 20, lineHeight: 26, fontWeight: '650' as const, letterSpacing: -0.2 },
  title3: { fontSize: 17, lineHeight: 23, fontWeight: '650' as const },
  body: { fontSize: 15, lineHeight: 21, fontWeight: '400' as const },
  bodyStrong: { fontSize: 15, lineHeight: 21, fontWeight: '600' as const },
  label: { fontSize: 13, lineHeight: 18, fontWeight: '600' as const },
  caption: { fontSize: 12, lineHeight: 16, fontWeight: '500' as const },
  tiny: { fontSize: 11, lineHeight: 14, fontWeight: '600' as const },
  number: { fontSize: 26, lineHeight: 30, fontWeight: '700' as const, fontVariant: ['tabular-nums'] as const }
};

export const fonts = Platform.select({ ios: { regular: 'System', rounded: 'System' }, android: { regular: 'sans-serif', rounded: 'sans-serif' }, default: { regular: 'System', rounded: 'System' } })!;

export const shadows = {
  floating: Platform.select({
    ios: { shadowColor: '#0F1820', shadowOpacity: 0.12, shadowRadius: 24, shadowOffset: { width: 0, height: 10 } },
    android: { elevation: 8 },
    default: {}
  }),
  sheet: Platform.select({
    ios: { shadowColor: '#0F1820', shadowOpacity: 0.18, shadowRadius: 36, shadowOffset: { width: 0, height: -6 } },
    android: { elevation: 16 },
    default: {}
  })
} as const;
